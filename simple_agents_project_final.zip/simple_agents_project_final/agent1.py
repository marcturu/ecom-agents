import os
import signal
import socket
from multiprocessing import Process, Queue

import requests
from flask import Flask, request
from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDF

from utils.ACL import ACL
from utils.ACLMessages import build_message, get_message_properties
from utils.Agent import Agent
from utils.FlaskServer import shutdown_server

# Configuration stuff
hostname = socket.gethostname()
port = 5001

# Directory agent address
directory_address = 'http://127.0.0.1:5000'
directory_address_register = f'{directory_address}/Register'
directory_address_get_agents = f'{directory_address}/GetAgents'

# Namespace for the ontology
FIPA_ACL = Namespace("http://www.nuin.org/ontology/fipa/acl#")
PRODUCT = Namespace("http://www.semanticweb.org/ontology/product#")

# Path to the ontology file
ontology_path = os.path.join(os.getcwd(), 'ontology', 'product_ontology.owl')

# Load ontology
g = Graph()
g.parse(ontology_path, format="xml")

# Global triplestore graph
dsgraph = Graph()

# Agent Definition
Agent1 = Agent('Agent1', PRODUCT.Agent1,
               f'http://{hostname}:{port}/comm', f'http://{hostname}:{port}/Stop')

# Flask app
app = Flask(__name__)


@app.route("/Stop")
def stop():
    try:
        shutdown_server()
    except Exception as e:
        print(f"Error stopping server: {e}")
        print('Using Alternative stopping method...')
        os.kill(os.getpid(), signal.SIGINT)
    return "Agent1 stopping..."


def agentbehavior(cola):
    while True:
        msg = cola.get()
        if msg == 'STOP':
            break
        print(f"Agent1 behavior received message: {msg}")


def get_agent_address(agent_name):
    response = requests.get(f'{directory_address_get_agents}')
    response_body = response.json()
    full_url = response_body.get(agent_name)
    if full_url:
        # Remove the last part after the last '/'
        base_url = full_url.rsplit('/', 1)[0]
        return base_url
    return None


@app.route("/comm", methods=['POST'])
def communicate():
    global dsgraph
    message = request.get_data()
    print("Agent1 received raw message data:", message)  # Debugging line
    gmess = Graph()
    gmess.parse(data=message, format='xml')
    print("Agent1 received message:", gmess.serialize(format='turtle'))

    msg_properties = get_message_properties(gmess)

    if msg_properties['performative'] and str(msg_properties['performative']) == str(ACL['inform']):
        # Process the response from Agent 2
        for s, p, o in gmess.triples((None, RDF.type, PRODUCT.Product)):
            product_name = gmess.value(subject=s, predicate=PRODUCT.hasName)
            product_price = gmess.value(subject=s, predicate=PRODUCT.hasPrice)
            return f"Received product info: {product_name} costs {product_price}"

    elif msg_properties['performative'] and str(msg_properties['performative']) == str(ACL['request']):
        # Extract the product request from the received message
        for s, p, o in gmess.triples((None, RDF.type, FIPA_ACL['ProductRequest'])):
            # Build the request message to Agent 2
            gmess_request = Graph()
            content = URIRef(FIPA_ACL['ProductRequest'])
            gmess_request.add((content, RDF.type, FIPA_ACL['ProductRequest']))
            gmess_request.add(
                (content, PRODUCT['hasName'], Literal('Example Product')))

            agent2_address = get_agent_address('Agent2')
            if agent2_address:
                sender_uri = URIRef(FIPA_ACL['Agent1'])
                receiver_uri = URIRef(FIPA_ACL['Agent2'])
                request_message = build_message(
                    gmess_request, ACL['request'], sender=sender_uri, receiver=receiver_uri, content=content)
                response = requests.post(
                    f'{agent2_address}/comm', data=request_message.serialize(format='xml'))
                return response.text

    return "No valid message received", 400


if __name__ == '__main__':
    # Register the agent in the directory service
    requests.post(directory_address_register, json={
                  'name': Agent1.name, 'address': Agent1.address})

    q = Queue()
    p = Process(target=agentbehavior, args=(q,))
    p.start()
    app.run(host=hostname, port=port)
    p.join()
