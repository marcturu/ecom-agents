
@echo off
echo Stopping Agent 1...
curl http://localhost:5001/Stop
timeout /t 2

echo Stopping Agent 2...
curl http://localhost:5002/Stop
timeout /t 2

echo Stopping Interface Agent...
curl http://localhost:5003/Stop
timeout /t 2

echo Stopping Directory Service...
taskkill /IM "python.exe" /F
