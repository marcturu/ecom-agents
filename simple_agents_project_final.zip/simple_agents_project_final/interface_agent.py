import socket

import requests
from flask import Flask, render_template, request
from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDF

from utils.ACL import ACL
from utils.ACLMessages import build_message

# Configuration stuff
hostname = socket.gethostname()
port = 5003

# Directory agent address
directory_address = 'http://127.0.0.1:5000'

# Namespace for the ontology
FIPA_ACL = Namespace("http://www.nuin.org/ontology/fipa/acl#")
PRODUCT = Namespace("http://www.semanticweb.org/ontology/product#")

# Agent addresses
agent1_address = None

# Flask app
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/send_request', methods=['POST'])
def send_request():
    global agent1_address
    if not agent1_address:
        agent1_address = get_agent_address('Agent1')

    if agent1_address:
        # Create the RDF message
        gmess = Graph()
        content = URIRef(FIPA_ACL['ProductRequest'])
        gmess.add((content, RDF.type, FIPA_ACL['ProductRequest']))
        gmess.add((content, PRODUCT['hasName'], Literal('Example Product')))

        sender_uri = URIRef(FIPA_ACL['InterfaceAgent'])
        receiver_uri = URIRef(FIPA_ACL['Agent1'])
        request_message = build_message(
            gmess, ACL['request'], sender=sender_uri, receiver=receiver_uri, content=content)

        # Send the message to Agent 1
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(
            f'{agent1_address}/comm', data=request_message.serialize(format='xml'), headers=headers)
        return response.text
    else:
        return "Agent1 address not found", 404


def get_agent_address(agent_name):
    response = requests.get(f'{directory_address}/GetAgents')
    response_body = response.json()
    full_url = response_body.get(agent_name)
    if full_url:
        # Remove the last part after the last '/'
        base_url = full_url.rsplit('/', 1)[0]
        return base_url
    return None


if __name__ == '__main__':
    app.run(host=hostname, port=port)
