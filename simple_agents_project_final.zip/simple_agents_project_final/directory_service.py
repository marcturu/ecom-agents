
from flask import Flask, request, jsonify

app = Flask(__name__)

# Dictionary to store agent addresses
agent_addresses = {}

@app.route('/Register', methods=['POST'])
def register_agent():
    content = request.json
    agent_name = content['name']
    agent_address = content['address']
    agent_addresses[agent_name] = agent_address
    return jsonify({'message': f'Agent {agent_name} registered successfully'}), 200

@app.route('/GetAgents', methods=['GET'])
def get_agents():
    return jsonify(agent_addresses), 200

@app.route('/GetAgent/<agent_name>', methods=['GET'])
def get_agent(agent_name):
    address = agent_addresses.get(agent_name)
    if address:
        return jsonify({'address': address}), 200
    else:
        return jsonify({'error': 'Agent not found'}), 404

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)
