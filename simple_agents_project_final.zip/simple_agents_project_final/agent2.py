import os
import signal
import socket
from multiprocessing import Process, Queue

import requests
from flask import Flask, request
from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDF

from utils.ACL import ACL
from utils.ACLMessages import build_message, get_message_properties
from utils.Agent import Agent
from utils.FlaskServer import shutdown_server

# Configuration stuff
hostname = socket.gethostname()
port = 5002

# Directory agent address
directory_address = 'http://127.0.0.1:5000'
directory_address_register = f'{directory_address}/Register'
directory_address_get_agents = f'{directory_address}/GetAgents'

# Namespace for the ontology
FIPA_ACL = Namespace("http://www.nuin.org/ontology/fipa/acl#")
PRODUCT = Namespace("http://www.semanticweb.org/ontology/product#")

# Path to the ontology file
ontology_path = os.path.join(os.getcwd(), 'ontology', 'product_ontology.owl')

# Load ontology
g = Graph()
g.parse(ontology_path, format="xml")

# Global triplestore graph
dsgraph = Graph()

# Agent Definition
Agent2 = Agent('Agent2', PRODUCT.Agent2,
               f'http://{hostname}:{port}/comm', f'http://{hostname}:{port}/Stop')

# Flask app
app = Flask(__name__)


@app.route("/Stop")
def stop():
    try:
        shutdown_server()
    except Exception as e:
        print(f"Error stopping server: {e}")
        print('Using Alternative stopping method...')
        os.kill(os.getpid(), signal.SIGINT)
    return "Agent2 stopping..."


def agentbehavior(cola):
    while True:
        msg = cola.get()
        if msg == 'STOP':
            break
        print(f"Agent2 behavior received message: {msg}")


@app.route("/comm", methods=['POST'])
def communicate():
    global dsgraph
    message = request.get_data()
    gmess = Graph()
    gmess.parse(data=message, format='xml')
    print("Agent2 received message:", gmess.serialize(format='turtle'))

    msg_properties = get_message_properties(gmess)

    if msg_properties['performative'] and str(msg_properties['performative']) == str(ACL['request']):
        for s, p, o in gmess.triples((None, RDF.type, FIPA_ACL['ProductRequest'])):
            # Create a response message with product info
            gmess_response = Graph()
            content = URIRef(PRODUCT['Product1'])
            gmess_response.add((content, RDF.type, PRODUCT['Product']))
            gmess_response.add(
                (content, PRODUCT['hasName'], Literal('Example Product')))
            gmess_response.add((content, PRODUCT['hasPrice'], Literal(100)))

            sender_uri = URIRef(FIPA_ACL['Agent2'])
            receiver_uri = URIRef(FIPA_ACL['Agent1'])

            response_message = build_message(
                gmess_response, ACL['inform'], sender=sender_uri, receiver=receiver_uri, content=content)
            return response_message.serialize(format='xml'), 200

    return "No valid message received", 400


if __name__ == '__main__':
    # Register the agent in the directory service
    requests.post(directory_address_register, json={
                  'name': Agent2.name, 'address': Agent2.address})

    q = Queue()
    p = Process(target=agentbehavior, args=(q,))
    p.start()
    app.run(host=hostname, port=port)
    p.join()
