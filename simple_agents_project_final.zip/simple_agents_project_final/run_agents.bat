
@echo off
echo Starting Directory Service...
start cmd /k "python directory_service.py"
timeout /t 1

echo Starting Agent 1...
start cmd /k "python agent1.py"
timeout /t 1

echo Starting Agent 2...
start cmd /k "python agent2.py"
timeout /t 1

echo Starting Interface Agent...
start cmd /k "python interface_agent.py"
